
from numpy import where, zeros_like

def asymLorentzian(params, t, etc = []):
   """
  This function creates a model that fits a sinusoid.

  Parameters
  ----------
    F0: flux offset
    c1: amplitude (kinda)
    c2: time offset
    c3: timescale of rise (kinda)
    c4:	timescale of fall (kinda)
    t:  Array of time/phase points

  Returns
  -------
	This function returns an array of y values...

  Revisions
  ---------
  2020-02-09	Laura Mayorga
                Be terrified
                Original version
   """
   F0, c_1, c_2, c_3, c_4 = params
   ut = zeros_like(t)
   ut[where(t <= c_2)] = (t[where(t <= c_2)]-c_2)/c_3
   ut[where(t > c_2)] = (t[where(t > c_2)]-c_2)/c_4
   return F0+c_1/(ut**2+1)

