
from numpy import max
from scipy import stats

def skewGauss(params, t, etc = []):
   """
  This function creates a model that fits a sinusoid.

  Parameters
  ----------
    k:      skewiness
    loc:	time offset
    scale:  sigma width
    amp1:   amplitude
    t:	    Array of time/phase points

  Returns
  -------
	This function returns an array of y values...

  Revisions
  ---------
  2020-02-03	Laura Mayorga
                Be terrified
                Original version
   """
   k, loc, scale, amp1 = params
   y = stats.exponnorm.pdf(t, k, loc=loc, scale=scale)

   return (y/max(y)*amp1+1)

